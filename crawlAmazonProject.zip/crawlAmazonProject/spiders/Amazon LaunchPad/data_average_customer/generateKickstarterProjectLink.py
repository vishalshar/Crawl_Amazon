import os
from bs4 import BeautifulSoup

# directory = "/home/vishal/Desktop/KickStarterOnAmazon/sampleAmazon/"
directory = "./"
dic = {}
target = open('./links.txt', 'w')


for root, dirs, files in os.walk(directory):
    for name in files:
        currentFile = os.path.join(root, name)
        print currentFile
        soup = BeautifulSoup(open(currentFile))
        for a in soup.find_all('a', href=True):
            url = a['href']
            if "amazon.com" in url and "customerReviews" not in url and 'offer-listing' not in url:
                if url not in dic:
                    dic[url] = 0
                    print url
                    target.write(url+"\n")

